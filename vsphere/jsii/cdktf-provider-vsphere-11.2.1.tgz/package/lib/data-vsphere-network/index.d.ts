/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataVsphereNetworkConfig extends cdktf.TerraformMetaArguments {
    /**
    * The managed object ID of the datacenter the network is in. This is required if the supplied path is not an absolute path containing a datacenter and there are multiple datacenters in your infrastructure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#datacenter_id DataVsphereNetwork#datacenter_id}
    */
    readonly datacenterId?: string;
    /**
    * Id of the distributed virtual switch of which the port group is a part of
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#distributed_virtual_switch_uuid DataVsphereNetwork#distributed_virtual_switch_uuid}
    */
    readonly distributedVirtualSwitchUuid?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#id DataVsphereNetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name or path of the network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#name DataVsphereNetwork#name}
    */
    readonly name: string;
    /**
    * Retry interval (in milliseconds) when probing the network
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#retry_interval DataVsphereNetwork#retry_interval}
    */
    readonly retryInterval?: number;
    /**
    * Timeout (in seconds) if network is not present yet
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#retry_timeout DataVsphereNetwork#retry_timeout}
    */
    readonly retryTimeout?: number;
    /**
    * Id of the VPC which the network belongs to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#vpc_id DataVsphereNetwork#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#filter DataVsphereNetwork#filter}
    */
    readonly filter?: DataVsphereNetworkFilter[] | cdktf.IResolvable;
}
export interface DataVsphereNetworkFilter {
    /**
    * The type of the network (e.g., Network, DistributedVirtualPortgroup, OpaqueNetwork)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#network_type DataVsphereNetwork#network_type}
    */
    readonly networkType?: string;
}
export declare function dataVsphereNetworkFilterToTerraform(struct?: DataVsphereNetworkFilter | cdktf.IResolvable): any;
export declare function dataVsphereNetworkFilterToHclTerraform(struct?: DataVsphereNetworkFilter | cdktf.IResolvable): any;
export declare class DataVsphereNetworkFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataVsphereNetworkFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataVsphereNetworkFilter | cdktf.IResolvable | undefined);
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
}
export declare class DataVsphereNetworkFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataVsphereNetworkFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataVsphereNetworkFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network vsphere_network}
*/
export declare class DataVsphereNetwork extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "vsphere_network";
    /**
    * Generates CDKTF code for importing a DataVsphereNetwork resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataVsphereNetwork to import
    * @param importFromId The id of the existing DataVsphereNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataVsphereNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/vmware/vsphere/2.15.0/docs/data-sources/network vsphere_network} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataVsphereNetworkConfig
    */
    constructor(scope: Construct, id: string, config: DataVsphereNetworkConfig);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    resetDatacenterId(): void;
    get datacenterIdInput(): string | undefined;
    private _distributedVirtualSwitchUuid?;
    get distributedVirtualSwitchUuid(): string;
    set distributedVirtualSwitchUuid(value: string);
    resetDistributedVirtualSwitchUuid(): void;
    get distributedVirtualSwitchUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _retryInterval?;
    get retryInterval(): number;
    set retryInterval(value: number);
    resetRetryInterval(): void;
    get retryIntervalInput(): number | undefined;
    private _retryTimeout?;
    get retryTimeout(): number;
    set retryTimeout(value: number);
    resetRetryTimeout(): void;
    get retryTimeoutInput(): number | undefined;
    get type(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _filter;
    get filter(): DataVsphereNetworkFilterList;
    putFilter(value: DataVsphereNetworkFilter[] | cdktf.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataVsphereNetworkFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
